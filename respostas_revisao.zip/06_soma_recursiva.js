// 6. Soma recursiva de uma lista

function somaRecursiva(lista) {
    if (lista.length === 0) {
        return 0;
    }
    return lista[0] + somaRecursiva(lista.slice(1));
}

let nums = [10, 20, 5, 3];
console.log(somaRecursiva(nums));
