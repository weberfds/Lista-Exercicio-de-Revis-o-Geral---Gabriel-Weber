// 11. Orientada a objetos

class Produto {
    constructor(codigo, nome, preco, quantidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    adicionarEstoque(qtd) {
        this.quantidade += qtd;
    }

    retirarEstoque(qtd) {
        if (qtd > this.quantidade) {
            console.log("Estoque insuficiente.");
        } else {
            this.quantidade -= qtd;
        }
    }

    alterarPreco(novoPreco) {
        this.preco = novoPreco;
    }

    calcularValorTotal() {
        return this.preco * this.quantidade;
    }
}

let prod1 = new Produto(1, "Caderno", 15.00, 10);
let prod2 = new Produto(2, "Caneta", 3.50, 50);
let prod3 = new Produto(3, "Borracha", 2.00, 20);

prod1.retirarEstoque(5);
console.log(prod1.calcularValorTotal());
