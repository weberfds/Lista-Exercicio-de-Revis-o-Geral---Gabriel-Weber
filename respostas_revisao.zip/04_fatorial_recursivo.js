// 4. Fatorial recursivo

function fatorial(n) {
    if (n === 0 || n === 1) {
        return 1;
    }
    return n * fatorial(n - 1);
}

console.log(fatorial(5));

/*
Respostas:
1. O caso-base da funcao e quando n e igual a 0 ou 1, retornando 1.
2. Se o caso-base nao existisse, a funcao chamaria a si mesma infinitamente, causando um erro de estouro de pilha.
3. Versao nao recursiva:
function fatorialIterativo(n) {
    let resultado = 1;
    for(let i = n; i > 1; i--) {
        resultado *= i;
    }
    return resultado;
}
*/
