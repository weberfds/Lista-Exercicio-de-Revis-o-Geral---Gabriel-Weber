-- 15. UPDATE e DELETE

UPDATE usuarios SET nome = 'Lucas Silva' WHERE id_usuario = 1;
UPDATE livros SET disponivel = FALSE WHERE id_livro = 1;
UPDATE emprestimos SET data_devolucao = '2023-10-15' WHERE id_emprestimo = 1;

-- DELETE FROM usuarios WHERE id_usuario = 2;
-- DELETE FROM livros WHERE id_livro = 3;

/*
Explicacao sobre chaves estrangeiras:
Ao tentar excluir um registro que possui chave estrangeira em outra tabela (por exemplo, um usuario que tem um emprestimo ativo), o banco de dados recusa a exclusao para evitar registros orfaos e manter a integridade referencial.
*/
