// 9. Sistema de atendimento utilizando fila

let fila = [];
let proximaSenha = 1;

function adicionarPessoa(nome) {
    let pessoa = {
        senha: proximaSenha++,
        nome: nome,
        horarioEntrada: new Date().toLocaleTimeString()
    };
    fila.push(pessoa);
}

function chamarProxima() {
    if (fila.length > 0) {
        return fila.shift();
    }
    return "Fila vazia";
}

function consultarProximo() {
    if (fila.length > 0) {
        return fila[0];
    }
    return "Ninguem na fila";
}

function mostrarFila() {
    return fila;
}

function pessoasAguardando() {
    return fila.length;
}

adicionarPessoa("Carlos");
adicionarPessoa("Maria");
console.log(chamarProxima());

/*
Explicacao:
Uma fila (FIFO - First In, First Out) e mais adequada porque o primeiro a chegar deve ser o primeiro a ser atendido, garantindo a ordem de chegada justa.
*/
