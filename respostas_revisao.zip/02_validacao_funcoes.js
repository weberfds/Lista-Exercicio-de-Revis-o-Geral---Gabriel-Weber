// 2. Validacao utilizando funcoes

function validarNome(nome) {
    return nome.trim() !== "";
}

function validarIdade(idade) {
    return idade >= 14 && idade <= 120;
}

function validarEmail(email) {
    return email.includes("@") && email.includes(".");
}

function validarSenha(senha) {
    return senha.length >= 8;
}

function cadastrarUsuario(nome, idade, email, senha) {
    if (validarNome(nome) && validarIdade(idade) && validarEmail(email) && validarSenha(senha)) {
        console.log("Cadastro concluido com sucesso!");
        return true;
    } else {
        console.log("Erro: Verifique os dados inseridos.");
        return false;
    }
}

cadastrarUsuario("Ana", 16, "ana@email.com", "senha1234");
