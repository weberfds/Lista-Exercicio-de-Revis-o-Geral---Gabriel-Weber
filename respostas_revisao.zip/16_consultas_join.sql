-- 16. Consultas relacionando tabelas

-- 1.
SELECT usuarios.nome, livros.titulo
FROM emprestimos
JOIN usuarios ON emprestimos.id_usuario = usuarios.id_usuario
JOIN livros ON emprestimos.id_livro = livros.id_livro;

-- 2.
SELECT * FROM emprestimos;

-- 3.
SELECT * FROM emprestimos WHERE data_devolucao IS NULL;

-- 4.
SELECT usuarios.nome, COUNT(emprestimos.id_emprestimo) AS total_emprestimos
FROM usuarios
LEFT JOIN emprestimos ON usuarios.id_usuario = emprestimos.id_usuario
GROUP BY usuarios.id_usuario;

-- 5.
SELECT livros.titulo
FROM livros
LEFT JOIN emprestimos ON livros.id_livro = emprestimos.id_livro
WHERE emprestimos.id_emprestimo IS NULL;
