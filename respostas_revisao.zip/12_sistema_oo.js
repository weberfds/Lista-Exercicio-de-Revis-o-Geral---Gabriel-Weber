// 12. Sistema orientado a objetos

class Pessoa {
    constructor(nome, dataNascimento) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
    }

    apresentar() {
        return "Nome: " + this.nome + ", Nascido em: " + this.dataNascimento;
    }
}

class Aluno extends Pessoa {
    constructor(nome, dataNascimento, matricula, curso, notas) {
        super(nome, dataNascimento);
        this.matricula = matricula;
        this.curso = curso;
        this.notas = notas; 
    }

    calcularMedia() {
        if (this.notas.length === 0) return 0;
        let soma = this.notas.reduce((a, b) => a + b, 0);
        return soma / this.notas.length;
    }

    apresentar() {
        return super.apresentar() + ", Curso: " + this.curso + ", Media: " + this.calcularMedia();
    }
}

class Professor extends Pessoa {
    constructor(nome, dataNascimento, matricula, disciplina) {
        super(nome, dataNascimento);
        this.matricula = matricula;
        this.disciplina = disciplina;
    }

    apresentar() {
        return super.apresentar() + ", Disciplina: " + this.disciplina;
    }
}

let aluno1 = new Aluno("Joao", "2005-04-10", "123", "Informatica", [8, 9, 7]);
let prof1 = new Professor("Rodrigo", "1980-05-20", "999", "Programacao II");

console.log(aluno1.apresentar());
console.log(prof1.apresentar());
