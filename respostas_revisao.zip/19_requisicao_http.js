// 19. Requisicao HTTP e API

const cep = "01001000";
const url = `https://viacep.com.br/ws/${cep}/json/`;

fetch(url)
    .then(resposta => {
        if (!resposta.ok) {
            throw new Error(`Erro HTTP! status: ${resposta.status}`);
        }
        return resposta.json();
    })
    .then(dados => {
        if (dados.erro) {
            console.log("CEP nao encontrado.");
        } else {
            console.log("Endereco encontrado:");
            console.log(`Rua: ${dados.logradouro}`);
            console.log(`Bairro: ${dados.bairro}`);
            console.log(`Cidade: ${dados.localidade} - ${dados.uf}`);
        }
    })
    .catch(erro => {
        console.error("Erro na requisicao:", erro);
    });

/*
Qual URL foi utilizada?
https://viacep.com.br/ws/01001000/json/

Qual metodo HTTP foi utilizado?
Metodo GET.

Qual codigo HTTP representa uma requisicao bem-sucedida?
Codigo 200.

Em qual formato os dados foram recebidos?
Formato JSON.

Qual e a diferenca entre uma requisicao e uma resposta HTTP?
Requisicao e o pedido que o cliente faz ao servidor. Resposta e o que o servidor devolve ao cliente.
*/
