// 1. Funcao para analise de numeros

function obterMaior(lista) {
    return Math.max(...lista);
}

function obterMenor(lista) {
    return Math.min(...lista);
}

function obterMedia(lista) {
    let soma = lista.reduce((acc, val) => acc + val, 0);
    return soma / lista.length;
}

function contarPares(lista) {
    return lista.filter(num => num % 2 === 0).length;
}

function contarImpares(lista) {
    return lista.filter(num => num % 2 !== 0).length;
}

let numeros = [10, 5, 8, 21, 3];
console.log("Maior: " + obterMaior(numeros));
console.log("Menor: " + obterMenor(numeros));
console.log("Media: " + obterMedia(numeros));
console.log("Pares: " + contarPares(numeros));
console.log("Impares: " + contarImpares(numeros));
