// 3. Calculadora modular

function somar(a, b) { return a + b; }
function subtrair(a, b) { return a - b; }
function multiplicar(a, b) { return a * b; }
function dividir(a, b) {
    if (b === 0) return "Erro: divisao por zero";
    return a / b;
}
function potencia(a, b) { return a ** b; }
function resto(a, b) { return a % b; }

function calculadora(operacao, a, b) {
    switch(operacao) {
        case "soma": return somar(a, b);
        case "subtracao": return subtrair(a, b);
        case "multiplicacao": return multiplicar(a, b);
        case "divisao": return dividir(a, b);
        case "potencia": return potencia(a, b);
        case "resto": return resto(a, b);
        default: return "Operacao invalida";
    }
}

console.log(calculadora("soma", 5, 3));
console.log(calculadora("divisao", 10, 0));
