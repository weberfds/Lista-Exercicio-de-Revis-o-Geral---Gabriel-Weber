// 7. Gerenciador de lista de tarefas

let tarefas = [];

function adicionarTarefa(descricao) {
    tarefas.push({ descricao: descricao, concluida: false });
}

function listarTarefas() {
    return tarefas;
}

function buscarTarefa(descricao) {
    return tarefas.find(t => t.descricao === descricao);
}

function alterarTarefa(antiga, nova) {
    let tarefa = buscarTarefa(antiga);
    if (tarefa) {
        tarefa.descricao = nova;
    }
}

function removerTarefa(descricao) {
    tarefas = tarefas.filter(t => t.descricao !== descricao);
}

function concluirTarefa(descricao) {
    let tarefa = buscarTarefa(descricao);
    if (tarefa) {
        tarefa.concluida = true;
    }
}

function quantidadeTarefas() {
    return tarefas.length;
}

adicionarTarefa("Estudar JS");
adicionarTarefa("Fazer exercicios");
concluirTarefa("Estudar JS");
console.log(listarTarefas());
