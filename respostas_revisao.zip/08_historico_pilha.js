// 8. Historico utilizando pilha

let historico = [];

function visitarPagina(url) {
    historico.push(url);
}

function visualizarAtual() {
    if (historico.length === 0) return "Sem historico";
    return historico[historico.length - 1];
}

function voltarPagina() {
    if (historico.length > 1) {
        historico.pop();
    } else {
        console.log("Nao e possivel voltar mais");
    }
}

function exibirHistorico() {
    return historico;
}

visitarPagina("google.com");
visitarPagina("github.com");
voltarPagina();
console.log(visualizarAtual());

/*
Explicacao:
Uma pilha (LIFO - Last In, First Out) e adequada porque o ultimo site visitado e o primeiro a ser removido quando clicamos no botao voltar do navegador.
*/
