// 5. Sequencia de Fibonacci

function fibonacciRecursivo(n) {
    if (n <= 1) return n;
    return fibonacciRecursivo(n - 1) + fibonacciRecursivo(n - 2);
}

function fibonacciIterativo(n) {
    if (n <= 1) return n;
    let a = 0, b = 1, temp;
    for (let i = 2; i <= n; i++) {
        temp = a + b;
        a = b;
        b = temp;
    }
    return b;
}

console.log("Recursivo:", fibonacciRecursivo(6));
console.log("Iterativo:", fibonacciIterativo(6));

/*
Comparacao:
A solucao com repeticao e mais eficiente para valores elevados de n. A versao recursiva recalcula os mesmos valores multiplas vezes (crescimento exponencial), enquanto a iterativa passa pelos numeros apenas uma vez (crescimento linear).
*/
