-- 14. INSERT e SELECT

INSERT INTO autores (nome, nacionalidade) VALUES ('Machado de Assis', 'Brasileira');
INSERT INTO autores (nome, nacionalidade) VALUES ('J.K. Rowling', 'Britanica');

INSERT INTO livros (titulo, ano_publicacao, disponivel, id_autor) VALUES ('Dom Casmurro', 1899, TRUE, 1);
INSERT INTO livros (titulo, ano_publicacao, disponivel, id_autor) VALUES ('Harry Potter e a Pedra Filosofal', 1997, TRUE, 2);
INSERT INTO livros (titulo, ano_publicacao, disponivel, id_autor) VALUES ('Memorias Postumas de Bras Cubas', 1881, TRUE, 1);
INSERT INTO livros (titulo, ano_publicacao, disponivel, id_autor) VALUES ('Harry Potter e a Camara Secreta', 1998, TRUE, 2);
INSERT INTO livros (titulo, ano_publicacao, disponivel, id_autor) VALUES ('Quincas Borba', 1891, FALSE, 1);

INSERT INTO usuarios (nome, telefone) VALUES ('Lucas', '999991111');
INSERT INTO usuarios (nome, telefone) VALUES ('Mariana', '999992222');
INSERT INTO usuarios (nome, telefone) VALUES ('Pedro', '999993333');

INSERT INTO emprestimos (id_livro, id_usuario, data_emprestimo, data_devolucao) VALUES (5, 1, '2023-10-01', NULL);
INSERT INTO emprestimos (id_livro, id_usuario, data_emprestimo, data_devolucao) VALUES (2, 2, '2023-09-15', '2023-09-30');
INSERT INTO emprestimos (id_livro, id_usuario, data_emprestimo, data_devolucao) VALUES (1, 3, '2023-10-10', NULL);


SELECT * FROM livros;
SELECT livros.titulo, autores.nome FROM livros JOIN autores ON livros.id_autor = autores.id_autor;
SELECT * FROM livros WHERE id_autor = 1;
SELECT * FROM livros ORDER BY titulo ASC;
SELECT * FROM livros WHERE disponivel = TRUE;
